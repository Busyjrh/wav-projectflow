# WAV ProjectFlow

Static GitHub Pages deployment for WAV ProjectFlow.

## Files
- `index.html` — ProjectFlow application
- `data/Yoko_Ono_REDCAT_ShootReady_UPDATED.json` — current Yoko Ono REDCAT ShootReady data
- `.nojekyll` — ensures GitHub Pages serves files directly

The WAV Estimator remains in a separate repository and is not included here.
